// backend/index.js
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const Web3 = require('web3');
const DonationABI = require('./abi/DonationContract.json').abi;
const DeliveryABI = require('./abi/DeliveryContract.json').abi;
const OrderABI = require('./abi/OrderContract.json').abi;

const app = express();
app.use(cors());
app.use(bodyParser.json());

// MySQL Database Connection
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'root', // Replace with your actual password
    database: 'blood_bank'
});

// Web3 Setup
const web3 = new Web3('http://127.0.0.1:8545');
const donationContract = new web3.eth.Contract(DonationABI, '0xfbBAeDc454f815bA2370C2994Baca970130c8288');
const deliveryContract = new web3.eth.Contract(DeliveryABI, '0x32aa140046998d5983C32A358C71DF3513f568B8');
const orderContract = new web3.eth.Contract(OrderABI, '0x8BA0a6A05453afDf8609F035442ED59139aaCBA2');
app.get('/getDonors', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM donor');
        console.log(rows); // This will print the receptionists to the backend console
        res.status(200).json(rows); // Send receptionist data as response
    } catch (error) {
        console.error('Error fetching receptionists:', error);
        res.status(500).json({ message: 'Failed to fetch receptionists' });
    }
});
app.get('/getLabTechnicians', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM lab_technician');
        res.status(200).json(rows);
    } catch (error) {
        console.error('Error fetching lab technicians:', error);
        res.status(500).json({ message: 'Failed to fetch lab technicians' });
    }
});

app.get('/getBloodBanks', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM blood_bank');
        console.log(rows); // This will print the receptionists to the backend console
        res.status(200).json(rows); // Send receptionist data as response
    } catch (error) {
        console.error('Error fetching receptionists:', error);
        res.status(500).json({ message: 'Failed to fetch receptionists' });
    }
});
// Register Donor
app.post('/registerDonor', async (req, res) => {
    const { donorName, dob, contactNumber, receptionistName } = req.body;

    try {
        // Fetch receptionist list from the database
        const [receptionists] = await db.execute('SELECT * FROM receptionist'); // Replace with the actual query

        // Find the receptionist ID (Rid) based on the name
        const receptionist = receptionists.find(rec => rec.Rname === receptionistName);
        const Rid = receptionist ? receptionist.Rid : null;

        // Insert the donor information into the database
        const [result] = await db.execute(
            'INSERT INTO donor (Dname, DOB, DContactNo, Rid) VALUES (?, ?, ?, ?)',
            [donorName, dob, contactNumber, Rid]
        );

        res.status(200).json({ message: 'Donor registered successfully!' });
    } catch (error) {
        console.error('Error registering donor:', error);
        res.status(500).json({ message: 'Failed to register donor' });
    }
});


// Record Donation
// Record Donation
app.post('/recordDonation', async (req, res) => {
    const { donor_name, blood_type, cost, blood_bank_name, lab_tech_name } = req.body;

    // Log the incoming data
    console.log('Received data in backend:', req.body);

    try {
        if (!donor_name || !blood_type || !blood_bank_name || !lab_tech_name) {
            console.error('Missing required fields:', { donor_name, blood_type, blood_bank_name, lab_tech_name });
            return res.status(400).json({ message: 'All fields are required.' });
        }

        // Fetch Donor ID from the database using donor_name
        const [donorResult] = await db.execute('SELECT Did FROM donor WHERE Dname = ?', [donor_name]);
        if (donorResult.length === 0) {
            return res.status(400).json({ message: `Donor not found: ${donor_name}` });
        }

        const Donor_ID = donorResult[0].Did;

        // Fetch IDs for blood bank and lab technician
        const [bloodBankResult] = await db.execute('SELECT Blood_bank_ID FROM blood_bank WHERE BBname = ?', [blood_bank_name]);
        const [labTechResult] = await db.execute('SELECT Tid FROM lab_technician WHERE Tech_name = ?', [lab_tech_name]);

        if (bloodBankResult.length === 0 || labTechResult.length === 0) {
            return res.status(400).json({ message: 'Invalid Blood Bank or Lab Technician Name.' });
        }

        const Blood_Bank_ID = bloodBankResult[0].Blood_bank_ID;
        const Tid = labTechResult[0].Tid;

        // Insert data into the database and store the result
        const [bloodInsertResult] = await db.execute(
            'INSERT INTO blood (Blood_type, Cost, Blood_bank_ID, Did, Tid) VALUES (?, ?, ?, ?, ?)',
            [blood_type, cost, Blood_Bank_ID, Donor_ID, Tid]
        );

        // Record on Blockchain
        const accounts = await web3.eth.getAccounts();
        await donationContract.methods
            .recordDonation(Donor_ID, bloodInsertResult.insertId)  // Use bloodInsertResult.insertId
            .send({ from: accounts[0] })
            .on('receipt', (receipt) => {
                console.log('Blockchain Transaction Hash:', receipt.transactionHash);
            });

        // Send success response
        res.status(200).json({ message: 'Donation recorded successfully!' });
    } catch (error) {
        console.error('Error recording donation:', error);
        res.status(500).json({ message: 'Failed to record donation' });
    }
});
app.post('/patients', async (req, res) => {
    const { pname, contactNo, hospitalName } = req.body;

    try {
        // Map hospital name to Hid
        const [hospital] = await db.execute('SELECT Hid FROM hospital WHERE Hname = ?', [hospitalName]);
        if (hospital.length === 0) {
            return res.status(404).json({ error: 'Hospital not found' });
        }

        const hid = hospital[0].Hid;

        // Insert patient data
        await db.execute('INSERT INTO patient (Pname, PContactNo, Hid) VALUES (?, ?, ?)', [pname, contactNo, hid]);
        res.status(201).json({ message: 'Patient registered successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to register patient' });
    }
});

// Backend - Record Delivery


// Endpoint to fetch all hospitals
app.get('/hospitals', async (req, res) => {
    try {
        const [hospitals] = await db.execute('SELECT Hname, Hid FROM hospital');
        console.log('Hospitals fetched:', hospitals);
        res.json(hospitals);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch hospitals' });
    }
});


app.post('/recordDelivery', async (req, res) => {
    const { hospitalName, patientName, bloodType } = req.body;

    try {
        // Step 1: Get hospital ID using hospital name
        const [hospitalResult] = await db.execute('SELECT Hid FROM hospital WHERE Hname = ?', [hospitalName]);
        if (hospitalResult.length === 0) {
            return res.status(404).json({ error: 'Hospital not found' });
        }
        const Hid = hospitalResult[0].Hid;

        // Step 2: Get patient ID using patient name and hospital ID
        const [patientResult] = await db.execute('SELECT Pid FROM patient WHERE Pname = ? AND Hid = ?', [patientName, Hid]);
        if (patientResult.length === 0) {
            return res.status(404).json({ error: 'Patient not found' });
        }
        const pid = patientResult[0].Pid;

        // Step 3: Get blood ID based on blood type from the 'orders' table
        const [bloodResult] = await db.execute(
            'SELECT Bid FROM orders WHERE Blood_bank_ID = ? AND Qty > 0 AND Bid IN (SELECT Bid FROM blood WHERE Blood_type = ?)', 
            [Hid, bloodType]
        );

        // If no matching blood record is found for the requested blood type
        if (bloodResult.length === 0) {
            return res.status(404).json({ error: 'No available blood of the requested type' });
        }

        const bloodId = bloodResult[0].Bid;

        // Step 4: Record delivery on the blockchain
        const accounts = await web3.eth.getAccounts();
        await deliveryContract.methods
            .recordDelivery(hospitalName, pid)  // Only pass hospital name and patient ID
            .send({ from: accounts[0] })
            .on('receipt', (receipt) => {
                console.log('Delivery recorded on blockchain. Transaction hash:', receipt.transactionHash);
                
                // Send response only once after recording delivery on blockchain
                res.status(200).json({
                    message: 'Delivery recorded',
                    transactionHash: receipt.transactionHash,  // Return transaction hash
                });
            });

        // Step 5: Update the delivery record in the database (delivers table)
        const [updateResult] = await db.execute(
            'UPDATE delivers SET Time = NOW(), Bid = ? WHERE Hid = ? AND Pid = ?',
            [bloodId, Hid, pid]
        );

        // If no rows were updated, insert a new record
        if (updateResult.affectedRows === 0) {
            const [insertResult] = await db.execute(
                'INSERT INTO delivers (Hid, Pid, Time, Bid) VALUES (?, ?, NOW(), ?)',
                [Hid, pid, bloodId]
            );
            if (insertResult.affectedRows === 0) {
                return res.status(500).json({ error: 'Failed to insert new delivery record.' });
            }
        }
    } catch (error) {
        console.error('Error recording delivery:', error);
        if (!res.headersSent) {
            res.status(500).json({ error: 'Failed to record delivery' });
        }
    }
});



// Place Order
app.post('/placeOrder', async (req, res) => {
    const { hospitalName, bloodBankName, bloodType, quantity } = req.body;

    try {
        // Fetch the hospital and blood bank IDs from the database based on names
        const [hospitalResult] = await db.execute('SELECT Hid FROM hospital WHERE HName = ?', [hospitalName]);
        const [bloodBankResult] = await db.execute('SELECT Blood_bank_ID FROM blood_bank WHERE BBName = ?', [bloodBankName]);

        if (hospitalResult.length === 0 || bloodBankResult.length === 0) {
            return res.status(400).json({ message: 'Hospital or Blood Bank not found' });
        }

        const Hid = hospitalResult[0].Hid;
        const Blood_Bank_ID = bloodBankResult[0].Blood_bank_ID;

        // Insert the order into the database (Bid will be auto-generated)
        await db.execute(
            'INSERT INTO orders (Hid, Blood_bank_ID, Qty) VALUES (?, ?, ?)',
            [Hid, Blood_Bank_ID, quantity]
        );

        // Record on Blockchain
        const accounts = await web3.eth.getAccounts();
        await orderContract.methods.placeOrder(Hid, Blood_Bank_ID).send({ from: accounts[0] })
            .on('receipt', receipt => {
                console.log('Order Transaction Hash:', receipt.transactionHash);
            });

        res.status(200).json({ message: 'Order placed successfully!' });
    } catch (error) {
        console.error('Error placing order:', error);
        res.status(500).json({ message: 'Failed to place order' });
    }
});


app.get('/patients', (req, res) => {
    db.execute('SELECT * FROM patient', (err, patients) => {
        if (err) {
            console.error('Error fetching patients:', err);
            return res.status(500).json({ message: 'Failed to fetch patients.' });
        }
        res.status(200).json(patients);
    });
});



// Get Receptionists
app.get('/getReceptionists', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM receptionist');
        console.log(rows); // This will print the receptionists to the backend console
        res.status(200).json(rows); // Send receptionist data as response
    } catch (error) {
        console.error('Error fetching receptionists:', error);
        res.status(500).json({ message: 'Failed to fetch receptionists' });
    }
});
app.get('/getDonors', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM donor');
        console.log(rows); // This will print the receptionists to the backend console
        res.status(200).json(rows); // Send receptionist data as response
    } catch (error) {
        console.error('Error fetching receptionists:', error);
        res.status(500).json({ message: 'Failed to fetch receptionists' });
    }
});
app.get('/getBloodBanks', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM blood_bank');
        console.log(rows); // This will print the receptionists to the backend console
        res.status(200).json(rows); // Send receptionist data as response
    } catch (error) {
        console.error('Error fetching receptionists:', error);
        res.status(500).json({ message: 'Failed to fetch receptionists' });
    }
});
// Start the Backend Server
app.listen(5000, () => {
    console.log('Backend running on http://localhost:5000');
});
